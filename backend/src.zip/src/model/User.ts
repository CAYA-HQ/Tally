import mongoose from "mongoose";
import { minLength } from "zod";

const userSchema = new mongoose.Schema({
  name: { type: String, required: [true, 'Name is required'],
    minLength: [2, 'Name must be at least 2 characters long']
  },
  email: { 
    type: String, required: [true, 'Email is required'], unique: true,
     match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email address']
   },
  phone: { type: Number, required: [true, 'Phone is required'] },
});

export const User = mongoose.model("User", userSchema);