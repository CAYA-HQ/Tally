import type { Request, Response } from "express";
import type { CreateUserInput } from "../model/validate.user";
import { createUserSchema } from "../model/validate.user";
import * as userService from "../service/user.service";

export let createUser = async (req: Request, res: Response) => {
    try {
        const data: CreateUserInput = req.body;
        const validatedData = createUserSchema.parse(data);
        const user = await userService.createUser(validatedData);

        //for testing purpose only, to check if the user is created successfully
        console.log(`welcome ${user.name}!`);

        res.status(201).json({
            success: true,
            data: user
        });
    } catch (error: any) {
        res.status(400).json({
            success: false,
            message: "Failed to create user",
            error: error.message
        });
    }
}

export let getUsers = async (req: Request, res: Response) => {
    try {
        const users = await userService.getUsers();
        res.status(200).json({
            success: true,
            data: users
        });
    } catch (error: any) {
        res.status(500).json({
            success: false,
            message: "Failed to fetch users",
            error: error.message
        });
    }
};

export let getUserById = async (req: Request, res: Response) => {
    try{
        const id = req.params.id as string;
        const user = await userService.getUserById(id);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }
        res.status(200).json({
            success: true,
            data: user
        });
    } catch (error: any) {
        res.status(500).json({
            success: false,
            message: "Failed to fetch user",
            error: error.message
        });
    }
}

export let updateUser = async (req: Request, res: Response) => {
    try{
        const id = req.params.id as string;
        const data = req.body;
        const validatedData = createUserSchema.parse(data);
        const user = await userService.updateUser(id, validatedData);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }
        res.status(200).json({
            success: true,
            data: user
        });
    } catch (error: any) {
        res.status(500).json({
            success: false,
            message: "Failed to update user",
            error: error.message
        });
    }
}

export let deleteUser = async (req: Request, res: Response) => {
    try{
        const id = req.params.id as string;
        const user = await userService.deleteUser(id)
        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found"
            });
        }  
        res.status(200).json({
            success: true,
            message: "User deleted successfully"
        });
    } catch (error: any) {
        res.status(500).json({
            success: false,
            message: "Failed to delete user",
            error: error.message
        });
    }
}