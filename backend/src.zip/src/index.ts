import express from "express";
import api from "./routes/api";
import cors from "cors"

export const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use("/api", api)
